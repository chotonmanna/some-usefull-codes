import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-manage-option',
  templateUrl: './manage-option.component.html',
  styleUrls: ['./manage-option.component.scss']
})
export class ManageOptionComponent implements OnInit {
  optionForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ManageOptionComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData,
  ) { }

  ngOnInit(): void {
    console.log(this.dialogData);
    this.optionForm = this.fb.group({
      id: [this.dialogData?.id || this.makeid()],
      position: [this.dialogData?.position, Validators.required],
      name: [this.dialogData?.name, Validators.required],
      weight: [this.dialogData?.weight, Validators.required],
      symbol: [this.dialogData?.symbol, Validators.required]
    });
  }

  makeid(length = 3) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  saveOptionData() {
    if (this.optionForm.valid) {
      this.dialogRef.close(this.optionForm.value);
    }
  }

}
