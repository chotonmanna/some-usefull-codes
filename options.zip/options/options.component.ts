import { Component, OnInit } from '@angular/core';
import { ManageOptionComponent } from './manage-option/manage-option.component';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';

export interface PeriodicElement {
  id: string;
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { id: 'sdf', position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
  { id: '44r', position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
  { id: 'xcv', position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
  { id: 'asx', position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
  { id: 'qw2', position: 5, name: 'Boron', weight: 10.811, symbol: 'B' }
];

@Component({
  selector: 'app-options',
  templateUrl: './options.component.html',
  styleUrls: ['./options.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class OptionsComponent implements OnInit {
  mainForm: FormGroup;
  displayedColumns: string[] = ['id', 'position', 'name', 'weight', 'symbol', 'actions'];
  dataSource: MatTableDataSource<PeriodicElement>;
  isEdit: boolean;
  listOfData: PeriodicElement[] = ELEMENT_DATA;

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.initializeOptionForm(this.listOfData);
  }

  private initializeOptionForm(data: PeriodicElement[]) {
    const optControls = [];
    data.forEach(row => {
      optControls.push(this.getOptionControls(row));
    });
    this.mainForm = this.fb.group({
      options: this.fb.array(optControls)
    });
    this.initializeDataSource(this.listOfData);
  }

  private updateOptionForm(data: PeriodicElement) {
    if (this.isEdit) {
      const index = this.listOfData.findIndex(row => row.id === data.id);

      // Update datasource
      this.listOfData[index] = {...this.listOfData[index], ...data};

      // Update form control value
      this.optionFormArray.at(index).patchValue(data);
    } else {
      // Update datasource
      this.listOfData.push(data);

      // Update form control value
      this.optionFormArray.push(this.getOptionControls(data));
    }
  
    this.initializeDataSource(this.listOfData);
  }

  private initializeDataSource(data: PeriodicElement[]) {
    this.dataSource = new MatTableDataSource(data);
  }

  private getOptionControls(data: PeriodicElement): FormGroup {
    return this.fb.group({
      id: data.id,
      name: data.name,
      position: data.position,
      weight: data.weight,
      symbol: data.symbol,
      checked: false
    });
  }

  get optionFormArray(): FormArray {
    return this.mainForm.get('options') as FormArray;
  }

  getFormGroupName(id): number {
    const index = this.optionFormArray.controls.findIndex((fa: FormGroup) => fa.value.id === id);
    return index;
  }

  manageOption(data: PeriodicElement = null) {
    this.isEdit = data ? true : false;
    this.dialog.open(ManageOptionComponent, {
      width: '600px',
      data
    }).afterClosed().subscribe(resp => resp && this.updateOptionForm(resp));
  }

  getAttributeForm(id): FormGroup {
    const fg = (this.optionFormArray.controls.find((fa: FormGroup) => fa.value.id === id) as FormGroup);
    return fg;
  }

}
