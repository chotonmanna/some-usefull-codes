import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { ManageAttributeComponent } from './manage-attribute/manage-attribute.component';

export interface PeriodicElement {
  id: string;
  slug: string;
  name: string;
  weight: number;
  symbol: string;
}

@Component({
  selector: 'app-attributes',
  templateUrl: './attributes.component.html',
  styleUrls: ['./attributes.component.scss']
})
export class AttributesComponent implements OnInit {
  @Input() form: FormGroup;
  @Input() optionData;
  displayedColumns: string[] = ['id', 'slug', 'name', 'weight', 'symbol', 'actions'];
  dataSource: MatTableDataSource<PeriodicElement>;
  isEdit: boolean;

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.initializeAttrForm();
  }

  private initializeAttrForm() {
    if (!this.optionData?.attributes) {
      this.optionData.attributes = [];
    }
    const attrControls = [];
    this.optionData.attributes.forEach(row => {
      attrControls.push(this.getAttrControls(row));
    });

    this.form.addControl('attributes', this.fb.array(attrControls))
    this.initializeDataSource(this.optionData.attributes);
  }

  private updateAttrForm(data: PeriodicElement) {
    if (this.isEdit) {
      const index = this.optionData.attributes.findIndex(row => row.id === data.id);

      // Update datasource
      this.optionData.attributes[index] = data;

      // Update form control value
      this.attrFormArray.at(index).patchValue(data);
    } else {
      // Update datasource
      this.optionData.attributes.push(data);

      // Update form control value
      this.attrFormArray.push(this.getAttrControls(data));
    }
  
    this.initializeDataSource(this.optionData.attributes);
  }

  private initializeDataSource(data: PeriodicElement[]) {
    this.dataSource = new MatTableDataSource(data);
  }

  private getAttrControls(data: PeriodicElement): FormGroup {
    return this.fb.group({
      id: data.id,
      name: data.name,
      weight: data.weight,
      symbol: data.symbol,
      slug: data.slug
    });
  }

  get attrFormArray(): FormArray {
    return this.form.get('attributes') as FormArray;
  }

  getFormGroupName(id): number {
    const index = this.attrFormArray.controls.findIndex((fa: FormGroup) => fa.value.id === id);
    return index;
  }

  manageAttribute(data: PeriodicElement = null) {
    this.isEdit = data ? true : false;
    this.dialog.open(ManageAttributeComponent, {
      width: '600px',
      data
    }).afterClosed().subscribe(resp => resp && this.updateAttrForm(resp));
  }

}
