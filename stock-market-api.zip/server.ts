
import * as http from 'http';
import {config} from 'dotenv';
import App from './src/app';
config();
const stockApp = new App();
const server = http.createServer(stockApp.express);
server.listen(process.env.PORT);
server.on('listening', () => {
  console.log('Server is listening...' + process.env.PORT);
});