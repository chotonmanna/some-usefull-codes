import { Request, Response, NextFunction, } from 'express';
import { Company } from '../models/company';

class CompanyController {
  async addNewCompany(req: Request, res: Response, next: NextFunction) {
    const newCompany = new Company(req.body);
    try {
      const response = await newCompany.save();
      res.send({ data: response });
    } catch (error) {
      //check unique code error
      const err = JSON.stringify(error);
      if (err.includes('11000')) {
        return next({ status: 400, message: 'Duplicate company code' });
      }
      return next({ status: 400, message: error });
    }
  }

  async getCompany(req: Request, res: Response, next: NextFunction) {
    try {
      let findWith = {};
      if (req.params?.companycode) {
        findWith = { code: req.params.companycode };
      }

      const data = await Company.find(findWith).select('-_id -__v -createdAt').exec();
      res.send({ data });
    } catch (error) {
      return next({ status: 500, message: error });
    }
  }

  async deleteCompany(req: Request, res: Response, next: NextFunction) {
    try {
      if (req.params?.companycode) {
        const findWith = { code: req.params.companycode };
        const checkExistData = await Company.find(findWith).select('-_id -__v -createdAt').exec();
        if (checkExistData.length) {
          await Company.findOneAndDelete(findWith);
          res.send({data: 'deleted'});
        } else {
          return next({ status: 400, message: 'Invalid Company code' });
        }
      } else {
        return next({ status: 400, message: 'Company code is required' });
      }
    } catch (error) {
      return next({ status: 500, message: error });
    }
  }
}

export default CompanyController;