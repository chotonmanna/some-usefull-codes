import { Request, Response, NextFunction, } from 'express';
import { addNew, getFromCode, deleteData } from '../models/company';

class CompanyController {
  async addNewCompany(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await addNew(req.body);
      res.send({ data });
    } catch (error) {
      //check unique code error
      const err = JSON.stringify(error);
      if (err.includes('11000')) {
        return next({ status: 400, message: 'Duplicate company code' });
      }
      return next({ status: 400, message: error });
    }
  }

  async getCompany(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await getFromCode(req.params?.companycode);
      res.send({ data });
    } catch (error) {
      return next({ status: 500, message: error });
    }
  }

  async deleteCompany(req: Request, res: Response, next: NextFunction) {
    try {
      if (req.params?.companycode) {
        const data = await deleteData(req.params.companycode);
        if (data === 0) {
          return next({ status: 400, message: 'Company code is not valid' });
        }
        if (data === 1) {
          return next({ status: 500, message: 'Unable to delete' });
        }
        if (data === 2) {
          res.send({data: 'deleted'});
        }
        
      } else {
        return next({ status: 400, message: 'Company code is required' });
      }
    } catch (error) {
      return next({ status: 500, message: error });
    }
  }
}

export default CompanyController;