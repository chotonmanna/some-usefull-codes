import { constants } from 'buffer';
import { Request, Response, NextFunction } from 'express';
import { StockPrice } from '../models/stock-price';

class StockPriceController {
  async getCompanyStockPrices(req: Request, res: Response, next: NextFunction) {
    try {
      const { companycode, startdate, enddate } = req.params;
      if (companycode && startdate && enddate) {
        const gteDate = new Date(startdate);
        const lteDate = new Date(enddate);

        gteDate.setDate(gteDate.getDate() - 1);
        lteDate.setDate(lteDate.getDate() + 1);

        const findWith = {
          companyCode: companycode,
          createdAt: { $gte: gteDate, $lte: lteDate }
        };
        const list = await StockPrice.find(findWith).select('price createdAt').exec();
        res.send({ data: list });
      } else {
        return res.send({ status: 400, message: 'Params are not valid' });
      }
    } catch (error) {
      return next({ status: 500, message: error });
    }
  }

  async addNewCompanyStockprice(req: Request, res: Response, next: NextFunction) {
    const postdata = {
      price: req.body.price,
      companyCode: req.params.companycode
    };
    const newCompany = new StockPrice(postdata);
    try {
      const response = await newCompany.save();
      res.send({ data: response });
    } catch (error) {
      return next({ status: 400, message: error });
    }
  }
}

export default StockPriceController;