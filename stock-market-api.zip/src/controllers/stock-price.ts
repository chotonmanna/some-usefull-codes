import { Request, Response, NextFunction } from 'express';
import { addNew } from '../models/stock-price';
import { getFromCode } from '../models/company';
import { getDateWithCurrentTZ } from '../shared/util';


class StockPriceController {
  async getCompanyStockPrices(req: Request, res: Response, next: NextFunction) {
    try {
      const { companycode, startdate, enddate } = req.params;
      if (companycode && startdate && enddate) {
        const sd = getDateWithCurrentTZ(startdate);
        const ed = getDateWithCurrentTZ(enddate);
        let company = await getFromCode(companycode);
        company = company[0];
        if (company.stockPriceList.length) {
          company.stockPriceList = company.stockPriceList.filter((row: any) => {
            return (row.createdAt >= sd && row.createdAt <= ed);
          });
        }
        // Calculate avg, min, max price
        let avg = 0, min = 0, max = 0;

        company.stockPriceList.forEach((stock: any) => {
          avg = avg + stock.price;
        });
        avg = avg / company.stockPriceList.length;
        const allPrices = company.stockPriceList.map((s: any) => s.price);
        allPrices.sort((a: number, b: number) => a - b);
        const data = {
          info: company,
          avg: Math.round(avg * 100) / 100,
          min: allPrices[0],
          max: allPrices[allPrices.length - 1]
        };

        res.send({
          data
        });
      } else {
        return res.send({ status: 400, message: 'Params are not valid' });
      }
    } catch (error) {
      console.log(error);
      return next({ status: 500, message: error });
    }
  }

  async addNewCompanyStockprice(req: Request, res: Response, next: NextFunction) {
    try {
      const response = await addNew(req.params.companycode, req.body.price);
      res.send({ data: response });
    } catch (error) {
      return next({ status: 400, message: error });
    }
  }
}

export default StockPriceController;