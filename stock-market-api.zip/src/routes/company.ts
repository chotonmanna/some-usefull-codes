import express, { Router } from 'express';
import CompanyController from '../controllers/company';

class CompanyRouter {
  private router: Router;
  private companyController: CompanyController;

  constructor() {
    this.router = express.Router();
    this.companyController = new CompanyController();
    this.initializeRouterConfig();
  }

  getRouter(): Router {
    return this.router;
  }

  private initializeRouterConfig() {
    this.router.post('/register', this.companyController.addNewCompany);
    this.router.get('/info/:companycode', this.companyController.getCompany);
    this.router.get('/getall', this.companyController.getCompany);
    this.router.delete('/delete/:companycode', this.companyController.deleteCompany);
  }
}

export default CompanyRouter;