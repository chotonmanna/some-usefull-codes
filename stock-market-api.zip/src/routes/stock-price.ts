import express, { Router } from 'express';
import StockPriceController from '../controllers/stock-price';

class StockPriceRouter {
  private router: Router;
  private stockPriceController: StockPriceController;

  constructor() {
    this.router = express.Router();
    this.stockPriceController = new StockPriceController();
    this.initializeRouterConfig();
  }

  getRouter(): Router {
    return this.router;
  }

  private initializeRouterConfig() {
    this.router.post('/add/:companycode', this.stockPriceController.addNewCompanyStockprice);
    this.router.get('/get/:companycode/:startdate/:enddate', this.stockPriceController.getCompanyStockPrices);
  }
}

export default StockPriceRouter;
