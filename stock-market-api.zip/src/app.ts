import express, { Application, Request, Response, NextFunction, Router } from "express";
import { connect, connection } from 'mongoose';
import { json, urlencoded } from 'body-parser';
import swaggerUi from 'swagger-ui-express'
import * as swaggerDocument from '../swagger/swagger.json';
import CompanyRouter from "./routes/company";
import StockPriceRouter from "./routes/stock-price";
import { appConstant } from "./shared/constant";
import cors from "cors";

// Add a list of allowed origins.
// If you have more origins you would like to add, you can add them to the array below.
const allowedOrigins = ['http://localhost:3000'];

const options: cors.CorsOptions = {
  origin: allowedOrigins
};

class App {
  private stockApp: Application;
  private basePathV1 = appConstant.baseUrl;
  private stockPriceRouter: StockPriceRouter;
  private companyRouter: CompanyRouter;

  constructor() {
    this.stockApp = express();
    this.stockPriceRouter = new StockPriceRouter();
    this.companyRouter = new CompanyRouter();
    this.configureAppMiddlewares();
    this.initializeAppRoutes();
    this.initializeAppMiddleware();
  }

  get express(): Application {
    return this.stockApp;
  }

  private configureAppMiddlewares() {
    this.stockApp.use(cors());
    this.stockApp.use(json());
    this.stockApp.use(urlencoded({ extended: true }));
    this.initDB(); // connect to mongodb
  }

  private initDB() {
    const { db } = appConstant;
    connect(db.url, db.config);
    connection
      .once('open', () => console.log('MongoDB Connected'))
      .on('error', (err) => console.log('MongoDB Error connect', err));
  }

  private initializeAppRoutes() {
    const { companyUrl, stockPriceUrl, swaggerUrl } = appConstant;
    this.stockApp.use(`${this.basePathV1}/${companyUrl}`, this.companyRouter.getRouter());
    this.stockApp.use(`${this.basePathV1}/${stockPriceUrl}`, this.stockPriceRouter.getRouter());
    this.stockApp.use(`${this.basePathV1}/${swaggerUrl}`, swaggerUi.serve, swaggerUi.setup(swaggerDocument)); 
  }

  private initializeAppMiddleware() {
    this.stockApp.use(this.errMiddleWare);
    this.stockApp.use(this.notFoundMiddleWare);
  }

  private errMiddleWare(err: any, req: Request, res: Response, next: NextFunction) {
    res.status(err.status || 500);
    res.send({ error: err.message });
  }

  private notFoundMiddleWare(req: Request, res: Response) {
    res.status(404);
    res.send({ error: "Not Found" });
  }
}

export default App;