export const getDateWithCurrentTZ = (date: string = '') => {
  const current = date ? new Date(date) : new Date();
  const getdate = new Date(Date.UTC(current.getFullYear(), current.getMonth(), current.getDate(), current.getHours(),
    current.getMinutes(), current.getSeconds(), current.getMilliseconds()));
  return getdate;
}