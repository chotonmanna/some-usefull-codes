export const appConstant = {
  baseUrl: '/api/v1.0',
  companyUrl: 'market/company',
  stockPriceUrl: 'market/stock',
  swaggerUrl: 'swagger',
  db: {
    url: 'mongodb://localhost:27017/stock-market',
    config: {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false
    }
  }
};