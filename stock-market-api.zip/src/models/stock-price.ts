import { Schema, model } from 'mongoose';

const stockPriceSchema = new Schema({
  companyCode: {
    type: String,
    required: [true, 'Company code is required']
  },
  price: {
    type: Number,
    required: [true, 'Price is required']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const StockPrice = model('StockPrice', stockPriceSchema);

export { StockPrice };