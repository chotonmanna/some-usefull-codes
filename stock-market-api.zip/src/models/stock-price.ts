import { Schema, model } from 'mongoose';
import { getFromCode, updateWithStock } from './company';
import { getDateWithCurrentTZ } from '../shared/util';


const stockPriceSchema = new Schema({
  company: {
    type: Schema.Types.ObjectId
  },
  price: {
    type: Number,
    required: [true, 'Price is required']
  },
  createdAt: {
    type: Date
  }
});

const StockPrice = model('StockPrice', stockPriceSchema);


const addNew = async (code: string, price: number) => {
  // First get company id from company code
  let company = await getFromCode(code);
  company = company[0];
  // Create new company stock price
  const companyNewStock = new StockPrice({ company: company._id, price, createdAt: getDateWithCurrentTZ() });
  const response = await companyNewStock.save();

  if (response) {
    // Update company with stock price id
    await updateWithStock(company._id, response._id);
  }

  return response;
}

const deleteAll = async (company: string) => {
  const resp = await StockPrice.deleteMany({ company });
  return resp;
}

export { addNew, deleteAll };
