import { Schema, model } from 'mongoose';

const companySchema = new Schema({
  name: {
    type: String,
    required: [true, 'Name is required']
  },
  code: {
    type: String,
    required: [true, 'Code is required'],
    unique: true
  },
  ceo: {
    type: String,
    required: [true, 'CEO is required']
  },
  turnover: {
    type: Number,
    required: [true, 'Turnover is required'],
    min: 10
  },
  stockEx: {
    type: String,
    required: [true, 'Stock Exchange is required']
  },
  website: {
    type: String,
    required: [true, 'Website is required'],
    validate: {
      validator: (val: string) => {
        const urlRegex = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-/]))?/;
        return urlRegex.test(val);
      },
      message: (props: { value: any; }) => `${props.value} is not a valid website`
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Company = model('Company', companySchema);

export { Company };