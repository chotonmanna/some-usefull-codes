import { Schema, model } from 'mongoose';
import { deleteAll } from './stock-price';
import { getDateWithCurrentTZ } from '../shared/util';

const companySchema = new Schema({
  name: {
    type: String,
    required: [true, 'Name is required']
  },
  code: {
    type: String,
    required: [true, 'Code is required'],
    unique: true
  },
  ceo: {
    type: String,
    required: [true, 'CEO is required']
  },
  turnover: {
    type: Number,
    required: [true, 'Turnover is required'],
    min: 10
  },
  stockEx: {
    type: String,
    required: [true, 'Stock Exchange is required']
  },
  website: {
    type: String,
    required: [true, 'Website is required'],
    validate: {
      validator: (val: string) => {
        const urlRegex = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-/]))?/;
        return urlRegex.test(val);
      },
      message: (props: { value: any; }) => `${props.value} is not a valid website`
    }
  },
  stockPriceList: [
    {
      type: Schema.Types.ObjectId,
      ref: "StockPrice"
    }
  ],
  createdAt: {
    type: Date
  }
});

const Company = model('Company', companySchema);

const addNew = async (data: any) => {

  const newCompany = new Company({ ...data, createdAt: getDateWithCurrentTZ() });
  const response = await newCompany.save();
  return response;
}

const getFromCode = async (code: string = '') => {
  let findWith = {};
  if (code) {
    findWith = { code };
  }
  const data = await Company.find(findWith)
    //.populate('stockPriceList', '-__v -company')
    .populate({ path: 'stockPriceList', select: '-__v -company', options: { sort: [{ 'createdAt': 'desc' }] } })
    .select('-__v -createdAt').exec();

  return data;
}

const updateWithStock = async (companyId: string, stockPriceId: string) => {
  await Company.findByIdAndUpdate(companyId,
    { $push: { stockPriceList: stockPriceId } },
    { new: true, useFindAndModify: false }).exec();
}

const deleteData = async (code: string) => {
  let status = 0; // Not a valid code
  const findWith = { code };
  const checkExistData = await Company.findOne(findWith).select('_id').exec();
  if (checkExistData) {
    const delStatus = await Company.findOneAndDelete(findWith).exec();
    if (delStatus) {
      await deleteAll(checkExistData._id);
      status = 2; // Deleted
    }
    status = 1; // Unable to delete 
  }

  return status;
}

export { addNew, getFromCode, updateWithStock, deleteData };