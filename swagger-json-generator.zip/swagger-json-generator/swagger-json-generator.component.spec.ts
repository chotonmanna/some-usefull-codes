import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwaggerJsonGeneratorComponent } from './swagger-json-generator.component';

describe('SwaggerJsonGeneratorComponent', () => {
  let component: SwaggerJsonGeneratorComponent;
  let fixture: ComponentFixture<SwaggerJsonGeneratorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwaggerJsonGeneratorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwaggerJsonGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
