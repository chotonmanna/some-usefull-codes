import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SwaggerServiceService } from './swagger-service.service';

@Component({
  selector: 'app-swagger-json-generator',
  templateUrl: './swagger-json-generator.component.html',
  styleUrls: ['./swagger-json-generator.component.scss']
})
export class SwaggerJsonGeneratorComponent implements OnInit {
  swaggerJsonForm: FormGroup;
  listOfComponents = [];
  editableCompIndex = -1;
  editableFormValue = null;

  constructor(
    private fb: FormBuilder,
    private swaggerService: SwaggerServiceService
  ) { }

  ngOnInit(): void {
    if (localStorage.getItem('listOfComponents')) {
      this.listOfComponents = JSON.parse(localStorage.getItem('listOfComponents'));
    }
    this.initForm();
  }

  private initForm() {
    this.swaggerJsonForm = this.fb.group({
      type: ['', Validators.required],
      name: ['', Validators.required]
    });
  }

  generateSwagger() {
    if (this.swaggerJsonForm.valid) {
      const jsonData = this.swaggerJsonForm.getRawValue();
      console.log(jsonData);
      let compObj = { key: jsonData.name, value: this.swaggerService.getValueOfComponent(jsonData) };
      console.log(compObj);

      if (this.editableCompIndex === -1) {
        this.listOfComponents.push(compObj);
      } else {
        this.listOfComponents[this.editableCompIndex] = compObj;
        this.editableCompIndex = -1;
        this.editableFormValue = null;
      }

      localStorage.setItem('listOfComponents', JSON.stringify(this.listOfComponents));
      this.initForm();
    }
  }

  onEditComponent(index) {
    this.editableCompIndex = index;
    const { type, value } = this.swaggerService.getEditableValue(this.listOfComponents[index].value);
    this.swaggerJsonForm.patchValue({ type, name: this.listOfComponents[index].key });
    this.editableFormValue = value;
  }

}
