import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SwaggerServiceService {

  constructor() { }

  getValueOfComponent(jsonData, value = null) {
    switch (jsonData.type) {
      case 'string':
      case 'number':
      case 'boolean':
        value = jsonData.value;
        break;
      case 'enum':
        value = jsonData.values;
        break;
      case 'object':
        value = {};
        jsonData.fields.forEach(element => {
          value[element.name] = this.getValueOfComponent(element, value[element.name]);
        });
        break;
      case 'array':
        value = [];
        jsonData.fields.forEach(element => {
          let obj = {};
          element.forEach(innerElem => {
            obj[innerElem.name] = this.getValueOfComponent(innerElem, obj[innerElem.name]);
          });
          value.push(obj);
        });
        break;
      default:
        break;
    }
    return value;
  }

  getEditableValue(value) {
    let updateValue = null;
    if (value instanceof Array) {
      if (value.every(entry => (typeof entry === 'string'))) {
        updateValue = { type: 'enum', value };
      } else {
        updateValue = { type: 'array', value: [] };
        value.forEach(elem => {
          const dt = this.getEditableValue(elem);
          updateValue.value.push(dt.value);
        });
      }
    } else if (value instanceof Object) {
      updateValue = { type: 'object', value: [] };
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const dt = this.getEditableValue(value[key]);
          const obj = { type: dt.type, name: key };
          if (['string', 'boolean', 'number'].includes(dt.type)) {
            obj['value'] = dt.value;
          } else if (dt.type === 'enum') {
            obj['values'] = dt.value;
          } else {
            obj['fields'] = dt.value;
          }
          updateValue.value.push(obj);
        }
      }
    } else {
      updateValue = { type: typeof value, value };
    }

    return updateValue;
  }
}
