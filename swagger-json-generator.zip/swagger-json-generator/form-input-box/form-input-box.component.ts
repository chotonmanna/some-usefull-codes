import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-form-input-box',
  templateUrl: './form-input-box.component.html',
  styleUrls: ['./form-input-box.component.scss']
})
export class FormInputBoxComponent implements OnChanges {
  @Input() form: FormGroup;
  @Input() formIndex: number = null;
  @Input() parent: FormArray = null;
  @Input() editableValue = null;

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.editableValue?.currentValue) {
      this.onChangeType(this.form.get('type').value, changes.editableValue.currentValue);
    }
  }

  onChangeType(type: string, editableValue = null) {
    if (this.form.contains('value')) {
      this.form.removeControl('value');
    }

    if (this.form.contains('fields')) {
      this.form.removeControl('fields');
    }

    if (['string', 'boolean', 'number'].includes(type)) {
      this.form.addControl('value', this.fb.control(editableValue || '', Validators.required));
    } else if (['object', 'array'].includes(type)) {
      let fa = [];
      if (editableValue) {
        if (type === 'object') {
          this.preloadFieldValuesForObject(fa, editableValue);
        } else {
          this.preloadFieldValuesForArray(fa, editableValue);
        }
      }
      this.form.addControl('fields', this.fb.array(fa));
    }
  }

  private preloadFieldValuesForObject(fa, editableValue) {
    editableValue.forEach(element => {
      const form = this.getFormGroup(element);
      if (['string', 'boolean', 'number'].includes(element.type)) {
        form.addControl('value', this.fb.control(element.value, Validators.required));
        fa.push(form);
      } else if (element.type === 'enum') {
        const enumArr = [];
        element.values.forEach(text => enumArr.push(this.fb.control(text, Validators.required)));
        form.addControl('values', this.fb.array(enumArr));
        fa.push(form);
      } else {
        form.addControl('fields', this.fb.array([]));
        fa.push(form);
        this.preloadFieldValuesForObject((form.get('fields') as FormArray), element.fields)
      }
    });
  }

  private preloadFieldValuesForArray(fa, editableValue) {
    editableValue.forEach(element => {
      console.log('11', element);
      let innerFA = this.fb.array([]);
      this.preloadFieldValuesForObject(innerFA, element);
      fa.push(innerFA);
    });
  }

  private getFormGroup(data = null) {
    return this.fb.group({
      type: [data?.type || '', Validators.required],
      name: [data?.name || '', Validators.required]
    });
  }

  addCompFields(data = null) {
    this.fieldsFormArray.push(this.getFormGroup(data));
  }

  get fieldsFormArray(): FormArray {
    if (this.form.contains('fields')) {
      return (this.form.get('fields') as FormArray);
    }
    return null;
  }

  addCompObjects() {
    this.fieldsFormArray.push(this.fb.array([]));
  }

  addCompObjectFields(index) {
    (this.fieldsFormArray.at(index) as FormArray).push(this.getFormGroup());
  }

  removeField() {
    this.parent.removeAt(this.formIndex);
  }

  removeObject(index: number) {
    this.fieldsFormArray.removeAt(index);
  }

}
