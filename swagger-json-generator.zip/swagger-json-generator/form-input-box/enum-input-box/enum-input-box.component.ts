import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormBuilder, Validators, FormGroup, FormArray } from '@angular/forms';
import { ENTER, COMMA } from '@angular/cdk/keycodes';

@Component({
  selector: 'app-enum-input-box',
  templateUrl: './enum-input-box.component.html',
  styleUrls: ['./enum-input-box.component.scss']
})
export class EnumInputBoxComponent implements OnChanges {
  @Input() form: FormGroup;
  @Input() editableValue: Array<string> = [];
  pathParam: FormControl;
  addOnBlur = true;
  readonly separatorKeysCodes = [ENTER, COMMA] as const;

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.pathParam) {
      this.form.addControl('values', this.fb.array([]));
      this.pathParam = this.fb.control('', Validators.required);
    }

    if (changes.editableValue?.currentValue) {
      this.valuesFormArray.clear();
      changes.editableValue?.currentValue.forEach(value => this.valuesFormArray.push(this.fb.control(value)));
    }
  }

  manageParam(index = -1): void {
    if (index > -1) {
      this.valuesFormArray.removeAt(index);
    } else {
      if (this.pathParam.valid) {
        this.valuesFormArray.push(this.fb.control(this.pathParam.value));
        this.pathParam.reset();
      }
    }
  }

  get valuesFormArray(): FormArray {
    if (this.form.contains('values')) {
      return (this.form.get('values') as FormArray);
    }
    return null;
  }

}
