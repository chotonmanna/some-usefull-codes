import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumInputBoxComponent } from './enum-input-box.component';

describe('EnumInputBoxComponent', () => {
  let component: EnumInputBoxComponent;
  let fixture: ComponentFixture<EnumInputBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumInputBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumInputBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
