import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-swagger-component-list',
  templateUrl: './swagger-component-list.component.html',
  styleUrls: ['./swagger-component-list.component.scss']
})
export class SwaggerComponentListComponent {
  @Input() listOfComponents;
  @Output() editComponent = new EventEmitter();

  constructor() { }

  clearData() {
    if (confirm('Are you sure to clear data ?')) {
      localStorage.clear();
    }
  }

  removeThisComp(index: number) {
    if (confirm('Are you sure to remove this component ?')) {
      this.listOfComponents.splice(index, 1);
      localStorage.setItem('listOfComponents', JSON.stringify(this.listOfComponents));
    }
  }

  editThisComp(index: number) {
    this.editComponent.emit(index);
  }

}
