import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwaggerComponentListComponent } from './swagger-component-list.component';

describe('SwaggerComponentListComponent', () => {
  let component: SwaggerComponentListComponent;
  let fixture: ComponentFixture<SwaggerComponentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwaggerComponentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwaggerComponentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
