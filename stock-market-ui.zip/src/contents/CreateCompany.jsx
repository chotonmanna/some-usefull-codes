import React, { Component } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

class CreateCompany extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <Box sx={{ width: '100%' }}>
        <Typography variant="h5" gutterBottom component="div">
          Create New Company
        </Typography>
        <div style={{ height: 400, width: '100%' }}>
          Company Form
        </div>
      </Box>
    );
  }
}

export default CreateCompany;
