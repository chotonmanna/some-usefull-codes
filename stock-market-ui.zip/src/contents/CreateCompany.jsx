import React, { Component } from 'react';
import Box from '@mui/material/Box';

class CreateCompany extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <Box sx={{ width: '100%' }}>
        Create New Company
      </Box>
    );
  }
}

export default CreateCompany;
