import React, { Component } from 'react';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';
import Typography from '@mui/material/Typography';
import { getAllCompany } from '../services/ApiService';

const columns = [
  { field: 'name', headerName: 'Name', width: 280 },
  { field: 'ceo', headerName: 'CEO', width: 150 },
  { field: 'code', headerName: 'Code', width: 100 },
  { field: 'turnover', headerName: 'Turnover (.cr)', type: 'number', width: 120 },
  { field: 'stockEx', headerName: 'StockEx.', width: 100 },
  { field: 'website', headerName: 'Website', width: 280 }
];

class CompanyList extends Component {
  constructor(props) {
    super(props);

    this.state = {
      list: { status: 0, data: null }
    };
  }

  componentDidMount() {
    getAllCompany().then(list => {
      if (list) {
        this.setState({ list });
      }
    });
  }

  render() {
    const { list } = this.state;
    return (
      <Box sx={{ width: '100%' }}>
        <Typography variant="h5" gutterBottom component="div">
          List of Companies
        </Typography>
        <div style={{ height: 400, width: '100%' }}>
          {list.status === 0 && <Typography variant="h6" gutterBottom component="div">Loading comapnies......</Typography>}
          {list.status === 1 && <Typography variant="h6" gutterBottom component="div">Unable to load companies</Typography>}
          {
            list.status === 2 &&
            <DataGrid
              rows={list.data}
              getRowId={row => row._id}
              columns={columns}
              pageSize={5}
              rowsPerPageOptions={[5]}
            />
          }
        </div>
      </Box>
    );
  }
}

export default CompanyList;
