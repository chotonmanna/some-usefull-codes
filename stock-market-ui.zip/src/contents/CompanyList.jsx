import React, { Component } from 'react';
import Box from '@mui/material/Box';
import SearchBox from '../elements/SearchBox';

class CompanyList extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <Box sx={{ width: '100%' }}>
        <SearchBox />
        List of Companies
      </Box>
    );
  }
}

export default CompanyList;
