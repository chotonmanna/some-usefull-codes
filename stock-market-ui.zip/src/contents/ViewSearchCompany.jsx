import React, { Component } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import ViewStockPriceDetails from './ViewStockPriceDetails';

class ViewSearchCompany extends Component {
  constructor(props) {
    super(props);
    this.state = {
      company: props.company
    };
  }

  componentDidUpdate(prevProps) {
    if (prevProps.company !== this.props.company) {
      const { company } = this.props;
      this.setState({ company });
    }
  }

  render() {
    const { info, avg, min, max } = this.state.company;
    return (
      <Box sx={{ width: '100%' }}>

        <Stack spacing={2} direction="row" justifyContent="space-between">
          <Stack direction="column">
            <Typography variant="h5" gutterBottom component="h5">
              {info.name}
            </Typography>
            <Typography variant="h7" gutterBottom component="div">
              <strong>CEO of {info.name}:</strong>&nbsp;&nbsp;{info.ceo}
            </Typography>
            <Typography variant="h7" gutterBottom component="div">
              <strong>Security Code:</strong>&nbsp;&nbsp;{info.code}
            </Typography>
            <Typography variant="h7" gutterBottom component="div">
              <strong>Stock Exchange:</strong>&nbsp;&nbsp;{info.stockEx}
            </Typography>
            <Typography variant="h7" gutterBottom component="div">
              <strong>Turnover:</strong>&nbsp;&nbsp;{info.turnover} (cr.)
          </Typography>
            {avg &&
              <Typography variant="h7" gutterBottom component="div">
                <strong>AVG Stock Price:</strong>&nbsp;&nbsp;{avg} INR
            </Typography>
            }
            {min &&
              <Typography variant="h7" gutterBottom component="div">
                <strong>Min Stock Price:</strong>&nbsp;&nbsp;{min} INR
            </Typography>
            }
            {max &&
              <Typography variant="h7" gutterBottom component="div">
                <strong>Max Stock Price:</strong>&nbsp;&nbsp;{max} INR
            </Typography>
            }
            <a href={info.website} target="_blank">View Website</a>
          </Stack>
          <ViewStockPriceDetails list={info.stockPriceList} />
        </Stack>
      </Box>
    );
  }
}

export default ViewSearchCompany;
