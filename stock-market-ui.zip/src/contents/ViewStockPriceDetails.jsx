import React, { Component } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import Typography from '@mui/material/Typography';

const columns = [
  { 
    field: 'price', 
    headerName: 'Price (INR)', 
    width: 150 
  },
  {
    field: 'createdAt',
    headerName: 'Date & Time',
    width: 250,
    valueGetter: (params) => {
      const ct = new Date(params.row.createdAt);
      return `${ct.toDateString()}, ${ct.toLocaleTimeString()}`;
    }
  }
];

class ViewStockPriceDetails extends Component {
  render() {
    return (
      <div style={{ height: 500, width: 500 }}>
        <Typography variant="h5" gutterBottom component="h5">
          Stock List
        </Typography>
        <DataGrid
          rows={this.props.list}
          getRowId={row => row._id}
          columns={columns}
          pageSize={15}
          rowsPerPageOptions={[15]}
        />
      </div>
    )
  }

}

export default ViewStockPriceDetails;