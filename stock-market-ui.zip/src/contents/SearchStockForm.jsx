import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import { getAllCompany } from '../services/ApiService';

class SearchStockForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      companyList: [],
      formControls: {
        company: '',
        startDate: '',
        endDate: ''
      },
      errorMsg: []
    };
  }

  componentDidMount() {
    getAllCompany().then(list => {
      if (list.status === 2) {
        this.setState({ companyList: list.data });
      }
    });
  }

  handleChangeValue(field, e) {
    this.setState(state => ({
      formControls: { ...state.formControls, [field]: e.target.value }
    }));
  }

  submitSearch() {
    if (this.checkErrorMessage()) {
      this.props.submitStockSearch(this.state.formControls);
    }
  }

  checkErrorMessage() {
    let { company, startDate, endDate } = this.state.formControls;
    const cd = new Date();
    const errorMsg = [];
    if (!company) {
      errorMsg.push('Please select a company');
    }

    if (!startDate) {
      errorMsg.push('Please select a valid start date');
    } else {
      startDate = new Date(startDate);
      if (startDate > cd) {
        errorMsg.push('Start date cannot be a future date');
      }
    }

    if (!endDate) {
      errorMsg.push('Please select a valid end date');
    } else {
      endDate = new Date(endDate);
      if (endDate > cd) {
        errorMsg.push('End date cannot be a future date');
      }
    }

    if (startDate && endDate && (startDate > endDate)) {
      errorMsg.push('Start date cannot be greater than end date');
    }

    this.setState({ errorMsg });
    return !errorMsg.length;
  }

  render() {
    const { companyList, formControls, errorMsg } = this.state;
    return (
      <Box
        component="form"
        sx={{ '& .MuiTextField-root': { m: 1, width: '25ch' } }}
        noValidate
        autoComplete="off"
      >
        <Stack spacing={2} direction="row" alignItems="baseline">
          <Stack spacing={2} direction="row">
            <FormControl sx={{ m: 1, minWidth: 230 }}>
              <InputLabel id="company">Company</InputLabel>
              <Select
                label="Select Company"
                value={formControls?.company || ''}
                onChange={this.handleChangeValue.bind(this, 'company')}>
                {companyList.map((comp, i) => <MenuItem key={i} value={comp.code}>{comp.name}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField
              id="startDate"
              label="Start Date"
              type="datetime-local"
              value={formControls.startDate}
              sx={{ width: 250 }}
              onChange={this.handleChangeValue.bind(this, 'startDate')}
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              id="endDate"
              label="End Date"
              type="datetime-local"
              value={formControls.endDate}
              sx={{ width: 250 }}
              onChange={this.handleChangeValue.bind(this, 'endDate')}
              InputLabelProps={{ shrink: true }}
            />
          </Stack>
          <Stack>
            <Button variant="contained" onClick={this.submitSearch.bind(this)}>Search Stock</Button>
          </Stack>
        </Stack>
        {
          errorMsg.length ?
          <ul className="error-msg">
            {errorMsg.map((err, i) => <li key={i}>{err}</li>)}
          </ul> : ''
        }
      </Box>
    );
  }
}

export default SearchStockForm;