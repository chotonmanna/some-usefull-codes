import React, { Component } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import SearchStockForm from './SearchStockForm';
import ViewSearchCompany from './ViewSearchCompany';
import { getSearchableCompany } from '../services/ApiService';

class CompanyStockList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchCriteria: null,
      searchStatus: -1,
      company: null
    };
  }

  onSubmitStockSearch(searchCriteria) {
    if (this.state.searchCriteria !== searchCriteria) {
      this.setState({ searchStatus: 0, searchCriteria });
      getSearchableCompany(searchCriteria).then(company => {
        if (company.status === 2) {
          this.setState({ status: 2, company: company.data });
        } else {
          this.setState({ searchStatus: 1 });
        }
      });
    }
  }

  render() {
    const { status, company } = this.state;
    return (
      <Box sx={{ width: '100%' }}>
        <Typography variant="h5" gutterBottom component="h5">
          Search Company Stock
        </Typography>
        <SearchStockForm submitStockSearch={this.onSubmitStockSearch.bind(this)} />
        <div style={{ height: 400, width: '100%' }}>
          {status === 0 && <Typography variant="h6" gutterBottom component="div">Search stock price......</Typography>}
          {status === 1 && <Typography variant="h6" gutterBottom component="div">Unable to load stock</Typography>}
          {status === 2 && <ViewSearchCompany company={company} />}
        </div>
      </Box>
    );
  }
}

export default CompanyStockList;
