import React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Header from './elements/Header';
import Footer from './elements/Footer';
import './App.css';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import CompanyList from './contents/CompanyList';
//import CreateCompany from './contents/CreateCompany';
import CompanyStockList from './contents/CompanyStockList';

const theme = createTheme();
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      tabs: [
        { label: 'Company Stock List', component: <CompanyStockList /> },
        { label: 'List of All Companies', component: <CompanyList /> },
        //{ label: 'Create New Company', component: <CreateCompany /> }
      ],
      value: 0
    }
  }

  handleChange(e, value) {
    this.setState({ value });
  }

  render() {
    const { tabs, value } = this.state;
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Header />
        <main>
          <Container sx={{ py: 8 }} maxWidth="md">
            <Box sx={{ width: '100%' }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={value} onChange={this.handleChange.bind(this)} aria-label="basic tabs example">
                  {tabs.map((tab, i) => <Tab key={i} label={tab.label} />)}
                </Tabs>
              </Box>
              {
                tabs.map((tab, i) =>
                  <TabPanel key={i} value={value} index={i}>
                    {tab.component}
                  </TabPanel>)
              }
            </Box>
          </Container>
        </main>
        <Footer />
      </ThemeProvider>
    );
  }
}