import React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Header from './elements/Header';
import Footer from './elements/Footer';
import './App.css';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import CompanyList from './contents/CompanyList';
import CreateCompany from './contents/CreateCompany';

const theme = createTheme();
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: 1
    }
  }

  handleChange(e, value) {
    this.setState({ value });
  }

  render() {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Header />
        <main>
          <Container sx={{ py: 8 }} maxWidth="md">
            <Box sx={{ width: '100%' }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={this.state.value} onChange={this.handleChange.bind(this)} aria-label="basic tabs example">
                  <Tab label="List of All Companies" />
                  <Tab label="Create New Company" />
                </Tabs>
              </Box>
              <TabPanel value={this.state.value} index={0}>
                <CompanyList />
              </TabPanel>
              <TabPanel value={this.state.value} index={1}>
                <CreateCompany />
              </TabPanel>
            </Box>
          </Container>
        </main>
        <Footer />
      </ThemeProvider>
    );
  }
}