import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';

class SearchBox extends React.Component {
  render() {
    return (
      <Box
        component="form"
        sx={{
          '& .MuiTextField-root': { m: 1, width: '25ch' },
        }}
        noValidate
        autoComplete="off"
      >
        <TextField id="outlined-search" label="Search field" type="search" />
      </Box>
    );
  }
}

export default SearchBox;