import { Box, Typography, Link } from "@mui/material";
import React from "react";
import '../App.css';

class Footer extends React.Component {
  render() {
    return (
      <Box sx={{ bgcolor: 'background.paper', p: 6 }} component="footer">
        <Typography variant="body2" color="text.secondary" align="center">
          {'Copyright © '}
          <Link color="inherit" href="https://mui.com/">
            http://www.stockmarket.com
          </Link>&nbsp;{' '}
          {new Date().getFullYear()}
          {'.'}
        </Typography>
      </Box>
    );
  }
}

export default Footer;