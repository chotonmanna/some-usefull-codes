import { AppBar, Toolbar, Typography } from "@mui/material";
import React from "react";
// @ts-ignore
import logo from '../img/logo.png';

class Header extends React.Component {
  render() {
    return (
      <AppBar position="relative">
        <Toolbar>
          <Typography variant="h6" color="inherit" noWrap>
            <img src={logo} alt="Stock Market" height={50} />
            <span className="logo-title">Stock Market</span>
          </Typography>
        </Toolbar>
        
      </AppBar>
    );
  }
}

export default Header;