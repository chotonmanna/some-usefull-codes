import axios from 'axios';
const basePath = 'http://localhost:3001/api/v1.0/market'

export const getAllCompany = async () => {
  try {
    const response = await axios.get(`${basePath}/company/getall`);
    return { status: 2, data: response.data.data };
  } catch (error) {
    return { status: 1 };
  }
}

export const getSearchableCompany = async ({company, startDate, endDate}) => {
  try {
    const response = await axios.get(`${basePath}/stock/get/${company}/${startDate}/${endDate}`);
    return { status: 2, data: response.data.data };
  } catch (error) {
    return { status: 1 };
  }
}