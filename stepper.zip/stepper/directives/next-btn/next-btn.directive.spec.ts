import { NextBtnDirective } from './next-btn.directive';

describe('NextBtnDirective', () => {
  it('should create an instance', () => {
    const directive = new NextBtnDirective();
    expect(directive).toBeTruthy();
  });
});
