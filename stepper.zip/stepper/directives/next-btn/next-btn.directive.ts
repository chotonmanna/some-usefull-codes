import { Directive, OnInit, Input, HostListener } from '@angular/core';
import { StepperComponent } from '../../components/stepper.component';

@Directive({
  selector: '[appStepperNext]',
})
export class NextBtnDirective implements OnInit {
  @Input() appStepperNext: StepperComponent;

  constructor() { }

  ngOnInit() {
    console.log(this.appStepperNext);
  }

  @HostListener('click', ['$event'])
  onClickBtn(e) {
    console.log(this.appStepperNext);
    this.appStepperNext.goToNextStep();
  }

}
