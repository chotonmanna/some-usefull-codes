import { Directive, Input, HostListener } from '@angular/core';
import { StepperComponent } from '../../components/stepper.component';

@Directive({
  selector: '[appStepperPrev]'
})
export class PrevBtnDirective {
  @Input() appStepperPrev: StepperComponent;

  constructor() { }

  ngOnInit() {
  }

  @HostListener('click', ['$event'])
  onClickBtn() {
    this.appStepperPrev.goToPrevStep();
  }
}
