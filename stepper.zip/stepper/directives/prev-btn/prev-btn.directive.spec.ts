import { PrevBtnDirective } from './prev-btn.directive';

describe('PrevBtnDirective', () => {
  it('should create an instance', () => {
    const directive = new PrevBtnDirective();
    expect(directive).toBeTruthy();
  });
});
