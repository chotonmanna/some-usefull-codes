import { Component, OnInit, Input, ViewChild, TemplateRef, AfterContentInit, AfterViewInit, ContentChild } from '@angular/core';
import {MatButton} from '@angular/material/button';

@Component({
  selector: 'app-step',
  templateUrl: './step.component.html',
  styleUrls: ['./step.component.scss']
})
export class StepComponent implements OnInit, AfterViewInit, AfterContentInit {
  @Input() name: string;
  @ViewChild('stepTemplate') template: TemplateRef<any>;
  @ContentChild('nextBtn') nextBtn: MatButton;

  constructor() { }

  ngOnInit(): void {
    //console.log('step -> onInit');
  }

  ngAfterViewInit() {
    //console.log(this.name);
  }

  ngAfterContentInit() {
    console.log(this.nextBtn?.color);
  }

}
