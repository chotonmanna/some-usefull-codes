import { Component, OnInit, ContentChildren, AfterContentInit, QueryList, Input } from '@angular/core';
import { StepComponent } from './step/step.component';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent implements OnInit, AfterContentInit {
  @Input() currentStep: number = 0;
  @ContentChildren(StepComponent, { descendants: false }) contentChildrenStepComp: QueryList<StepComponent>;

  stepWidth: string;
  allSteps: Array<StepComponent> = [];
  completedSteps: Array<number> = [];

  constructor() { }

  ngOnInit(): void {

  }

  ngAfterContentInit() {
    setTimeout(() => {
      this.contentChildrenStepComp.toArray().forEach(step => {
        this.allSteps.push(step);
      });

      this.calculateStepWidth();
    });
  }

  private calculateStepWidth() {
    const totalSteps = 100 / this.allSteps.length;
    this.stepWidth = (Math.round(totalSteps * 100) / 100).toFixed(2);
    this.stepWidth = `${this.stepWidth}%`;
  }

  get totalStepCount(): number {
    return this.allSteps.length;
  }

  isCurrentStep(stepIndex: number): boolean {
    return this.currentStep === stepIndex;
  }

  isCompletedStep(stepIndex: number): boolean {
    return this.completedSteps.includes(stepIndex);
  }

  goToNextStep() {
    if (this.currentStep < (this.totalStepCount - 1)) {
      if (!this.completedSteps.includes(this.currentStep)) {
        this.completedSteps.push(this.currentStep);
      }
      this.currentStep++;
    }
  }

  goToPrevStep() {
    if (this.currentStep >= 0) {
      this.currentStep--;
    }
  }

}
