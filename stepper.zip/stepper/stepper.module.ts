import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StepComponent } from './components/step/step.component';
import { StepperComponent } from './components/stepper.component';
import { NextBtnDirective } from './directives/next-btn/next-btn.directive';
import { PrevBtnDirective } from './directives/prev-btn/prev-btn.directive';

const comps = [
  StepperComponent,
  StepComponent,
  NextBtnDirective, 
  PrevBtnDirective
]


@NgModule({
  declarations: [...comps],
  imports: [
    CommonModule
  ],
  exports: [...comps]
})
export class StepperModule { }
