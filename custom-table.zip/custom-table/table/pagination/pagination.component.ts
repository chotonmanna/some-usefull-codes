import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Paginator } from '../../data-types/Table';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {
  @Input() length: number;
  @Output() changePaginator = new EventEmitter<Paginator>();
  listOfItemsPerPage = [5, 10, 25, 50];
  itemsPerPageCtrl = new FormControl(this.listOfItemsPerPage[0]);
  paginator: Paginator;
  currentPageObs = new BehaviorSubject<number>(1);

  constructor() { }

  ngOnInit(): void {
    this.currentPageObs.asObservable().subscribe(page => {
      this.initPaginator(page);
    });
    this.itemsPerPageCtrl.valueChanges.subscribe(() => {
      this.currentPageObs.next(1);
    });
  }

  private initPaginator(currentPage) {
    const start = (currentPage - 1) * this.itemsPerPageCtrl.value;
    const end = start + this.itemsPerPageCtrl.value;
    this.paginator = { start, end };

    this.changePaginator.emit(this.paginator);
  }

  onChangePrev() {
    let currentPage = this.currentPageObs.value;
    if (currentPage > 1) {
      currentPage--;
    }
    this.currentPageObs.next(currentPage);
  }

  onChangeNext() {
    const totalPage = Math.ceil(this.length / this.itemsPerPageCtrl.value);
    let currentPage = this.currentPageObs.value;
    if (currentPage < totalPage) {
      currentPage++;
    }
    this.currentPageObs.next(currentPage);
  }

  onChangeFirst() {
    this.currentPageObs.next(1);
  }

  onChangeLast() {
    this.currentPageObs.next(Math.ceil(this.length / this.itemsPerPageCtrl.value));
  }

}
