import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TableHeader } from '../../data-types/Table';
import {MatSelectChange} from '@angular/material/select';
import { StorageService } from '../../services/storage.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-manage-filter-column',
  templateUrl: './manage-filter-column.component.html',
  styleUrls: ['./manage-filter-column.component.scss']
})
export class ManageFilterColumnComponent implements OnInit {
  //@Input() dataSource: any;
  @Input() storage: StorageService;
  selectColumns = new FormControl('');
  headers$: Observable<Array<TableHeader>>;
  dataSource$: Observable<Array<any>>;
  constructor() { }

  ngOnInit(): void {
    this.headers$ = this.storage.headers$;
  }

  onChange(e: MatSelectChange) {
    console.log(e.value);
    console.log(this.selectColumns.value);
  }

}
