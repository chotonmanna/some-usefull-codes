import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFilterColumnComponent } from './manage-filter-column.component';

describe('ManageFilterColumnComponent', () => {
  let component: ManageFilterColumnComponent;
  let fixture: ComponentFixture<ManageFilterColumnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageFilterColumnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageFilterColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
