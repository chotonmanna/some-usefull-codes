import { Component, OnInit, ViewChild, AfterViewInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { TableHeader } from '../../data-types/Table';
import { startWith } from 'rxjs/operators';

@Component({
  selector: 'app-filter-column',
  templateUrl: './filter-column.component.html',
  styleUrls: ['./filter-column.component.scss']
})
export class FilterColumnComponent implements OnInit {
  @ViewChild('filterMenu') trigger: MatMenuTrigger;

  @Input() columnName: string;
  @Input() storage: StorageService;
  @Input() displayedInHeader = true;

  filterableData: Array<string>;
  filterTextCtrl = new FormControl('');

  header: TableHeader;
  dataSource: Array<any>;
  selectedCheckboxValues: Array<string> = [];

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    // Take backup of main datasource and search will perform based on this backup datasource
    this.dataSource = this.storage.dataSource$.value;
    this.header = this.storage.headers$.value.find(row => row.id === this.columnName);
    this.initializeFilterData();
  }

  private initializeFilterData() {
    this.filterableData = this.dataSource
      .map(row => row[this.columnName])
      .filter((item, pos, inputArray) => inputArray.indexOf(item) == pos);
  }

  get isBtnDisabled(): boolean {
    return !!this.selectedCheckboxValues.length;
  }

  onChangeFilterText(text = null) {
    this.initializeFilterData();
    if (text) {
      text = text.toLowerCase();
      this.filterableData = this.filterableData.filter((val: string) => val.toLowerCase().includes(text));
    } else {
      this.filterTextCtrl.reset();
    }
  }

  onChangeData(text) {
    const index = this.selectedCheckboxValues.indexOf(text);
    if (index === -1) {
      this.selectedCheckboxValues.push(text);
    } else {
      this.selectedCheckboxValues.splice(index, 1);
    }
  }

  isCheckedData(item): boolean {
    return this.selectedCheckboxValues.includes(item);
  }

  clearFilter() {
    this.selectedCheckboxValues = [];
    this.filterTextCtrl.reset();
    this.initializeFilterData();
    this.processFilter();
  }

  processFilter() {
    this.storage.notifyFilterableParams(this.columnName, this.selectedCheckboxValues);
  }

}
