import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-keyword-search',
  templateUrl: './keyword-search.component.html',
  styleUrls: ['./keyword-search.component.scss']
})
export class KeywordSearchComponent implements OnInit {
  @Output() changeKeyword = new EventEmitter<string>();
  keywordCtrl = new FormControl('');

  constructor() { }

  ngOnInit(): void {
    this.keywordCtrl.valueChanges.pipe(debounceTime(600))
    .subscribe(text => {
      this.changeKeyword.emit(text);
    });
  }

  clearSearchKeyword() {
    this.keywordCtrl.setValue('');
    this.changeKeyword.emit('');
  }

}
