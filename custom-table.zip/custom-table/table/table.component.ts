import { Component, OnInit, Input, OnChanges, SimpleChanges, ContentChild, TemplateRef } from '@angular/core';
import { TableService } from '../services/table.service';
import { TableHeader, Paginator, SortParam } from '../data-types/Table';
import { StorageService } from '../services/storage.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit, OnChanges {
  @ContentChild('header') tableHeader: TemplateRef<any>;
  @ContentChild('body') tableBody: TemplateRef<any>;
  @ContentChild('actions') rowActions: TemplateRef<any>;
  @ContentChild('footer') tableFooter: TemplateRef<any>;

  @Input() data: Array<any>;
  @Input() headers: Array<TableHeader>;
  @Input() class = 'custom-table';
  defaultAlign = 'left';
  dataSource$: Observable<Array<any>>;
  storage: StorageService;
  searchKeyword: string;
  paginator = { start: 0, end: 5 } as Paginator;
  sortParam: SortParam;

  isSortActiveHeader(columnName: string): boolean {
    return this.sortParam?.columnName === columnName;
  }

  constructor(
    private tableService: TableService
  ) { }

  ngOnInit(): void {
    if (!this.headers) {
      this.headers = this.tableService.getHeadersFromData(this.data);
    }
    this.storage = new StorageService(this.headers, this.data);
    this.dataSource$ = this.storage.dataSource$;

    this.storage.sortableParams$.asObservable().subscribe(param => this.sortParam = param);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes?.headers?.currentValue) {
      this.headers = this.tableService.setDefaultHeaders(changes.headers.currentValue);

      if (this.storage) {
        this.storage.notifyHeaders(this.headers);
      }
    }
  }

  onChangeKeyword(keyword: string) {
    this.searchKeyword = keyword;
  }

  onChangePaginator(paginator: Paginator) {
    this.paginator = paginator;
  }

}
