import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { StorageService } from '../../services/storage.service';
import { TableHeader, SortBy } from '../../data-types/Table';

@Component({
  selector: 'app-sort-column',
  templateUrl: './sort-column.component.html',
  styleUrls: ['./sort-column.component.scss']
})
export class SortColumnComponent implements OnInit {
  @Input() columnName: string;
  @Input() isActive: boolean;
  @Input() storage: StorageService;
  header: TableHeader;
  initialSortBy: SortBy;
  constructor() { }

  ngOnInit(): void {
    this.header = this.storage.headers$.value.find(row => row.id === this.columnName);
  }

  sortDataSource() {
    if (!this.initialSortBy) {
      this.initialSortBy = 'asc';
    } else if (this.initialSortBy === 'asc') {
      this.initialSortBy = 'desc';
    } else {
      this.initialSortBy = null;
    }
    this.storage.notifySortableParams(this.columnName, this.header.sortAs, this.initialSortBy);
  }

}
