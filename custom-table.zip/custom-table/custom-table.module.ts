import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponent } from './table/table.component';
import { TableService } from './services/table.service';
import { MatIconModule } from '@angular/material/icon';
import { FilterColumnComponent } from './table/filter-column/filter-column.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FilterDirective } from './directives/filter.directive';
import { SortDirective } from './directives/sort.directive';
import { MatButtonModule } from '@angular/material/button';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ManageFilterColumnComponent } from './table/manage-filter-column/manage-filter-column.component';
import { KeywordSearchComponent } from './table/keyword-search/keyword-search.component';
import { SearchByKeyPipe } from './pipes/search-by-key.pipe';
import { PaginationComponent } from './table/pagination/pagination.component';
import { SortColumnComponent } from './table/sort-column/sort-column.component';
import { SortByParamPipe } from './pipes/sort-by-param.pipe';

@NgModule({
  declarations: [
    TableComponent,
    FilterColumnComponent,
    FilterDirective,
    SortDirective,
    ManageFilterColumnComponent,
    KeywordSearchComponent,
    SearchByKeyPipe,
    SortByParamPipe,
    PaginationComponent,
    SortColumnComponent
  ],
  imports: [
    CommonModule,
    MatIconModule,
    MatMenuModule,
    MatCheckboxModule,
    MatButtonModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [TableService],
  exports: [
    TableComponent,
    FilterDirective,
    SortDirective
  ]
})
export class CustomTableModule { }
