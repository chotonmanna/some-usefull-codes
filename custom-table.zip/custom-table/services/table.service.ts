import { TableHeader } from '../data-types/Table';

export class TableService {

  constructor() { }

  getHeadersFromData(data: Array<unknown>) {
    let headerKeys = Object.keys(data[0]);
    const header: Array<TableHeader> = headerKeys.map(id => {
      return {
        id,
        label: this.toTitleCase(id),
        visible: true
      }
    });

    return header;
  }

  private toTitleCase(str) {
    return str.replace(
      /\w\S*/g,
      (txt) => {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      }
    );
  }

  setDefaultHeaders(headers: Array<TableHeader>): Array<TableHeader> {
    return headers.map((header: TableHeader) => {
      if (typeof header.visible === 'undefined') {
        header.visible = true;
      }

      if (typeof header.filter === 'undefined') {
        header.filter = false;
      }
      return header;
    });
  }
}
