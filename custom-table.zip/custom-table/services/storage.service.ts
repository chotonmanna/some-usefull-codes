import { TableHeader, SortAs, SortBy, SortParam } from "../data-types/Table";
import { BehaviorSubject } from "rxjs";

export class StorageService {
  headers$ = new BehaviorSubject<Array<TableHeader>>(null);
  dataSource$ = new BehaviorSubject<Array<any>>(null);
  mainDataSource: Array<any> = [];
  private filterableParams$ = new BehaviorSubject({});
  sortableParams$ = new BehaviorSubject<SortParam>(null);

  constructor(headers, dataSource) {
    this.mainDataSource = dataSource; // Get copy of data source
    this.notifyHeaders(headers);
    this.notifyDataSource(dataSource);

    this.triggerDataSourceByFilterableParams();
    //this.triggerDataSourceBySortableParams();
  }

  notifyHeaders(headers: Array<TableHeader>) {
    this.headers$.next(headers);
  }

  notifyDataSource(dataSource: Array<any>) {
    this.dataSource$.next(dataSource);
  }

  notifyFilterableParams(columnName: string, paramValues: Array<string>) {
    const columnValues = this.filterableParams$.value;
    if (paramValues.length) {
      columnValues[columnName] = paramValues;
    } else {
      delete columnValues[columnName];
    }

    this.filterableParams$.next(columnValues);
  }

  private triggerDataSourceByFilterableParams() {
    this.filterableParams$.asObservable().subscribe(columnValues => {
      if (Object.keys(columnValues).length) {
        let filteredData = this.mainDataSource;
        for (const column in columnValues) {
          if (columnValues[column]) {
            filteredData = filteredData.filter(row => {
              return columnValues[column].includes(row[column]);
            });
          }
        }
        this.notifyDataSource(filteredData);
      }
    });

  }

  notifySortableParams(columnName: string, sortAs: SortAs, sortBy: SortBy) {
    let sortParam: SortParam = this.sortableParams$.value;
    if (sortParam) {
      if (sortParam.columnName !== columnName) {
        sortParam = { columnName, sortAs, sortBy };
      } else {
        sortParam.sortBy = sortBy;
      }
    } else {
      sortParam = { columnName, sortAs, sortBy };
    }
    this.sortableParams$.next(sortParam);
  }

}