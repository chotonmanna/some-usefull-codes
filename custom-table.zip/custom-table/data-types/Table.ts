export interface TableHeader {
  id: string;
  label: string;
  align?: 'center' | 'left' | 'right';
  visible?: true | false;
  filter?: true | false;
  sortAs?: 'text' | 'number' | 'date';
}

export interface Paginator {
  start: number;
  end: number;
}

export type SortAs = 'text' | 'number' | 'date';
export type SortBy = 'asc' | 'desc';

export interface SortParam {
  columnName: string;
  sortAs: SortAs;
  sortBy: SortBy;
}