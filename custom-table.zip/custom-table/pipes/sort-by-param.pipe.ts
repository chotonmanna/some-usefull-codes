import { Pipe, PipeTransform } from '@angular/core';
import { SortParam } from '../data-types/Table';

@Pipe({
  name: 'sortByParam'
})
export class SortByParamPipe implements PipeTransform {

  transform(results: Array<any>, columnName, sortAs, sortBy): Array<any> {
    if (columnName && sortAs && sortBy) {
      return this.triggerDataSourceBySortableParams(results, { columnName, sortAs, sortBy });
    }

    return results;
  }

  private triggerDataSourceBySortableParams(results: Array<any>, param: SortParam) {
    let sortedData = JSON.parse(JSON.stringify(results));
    if (param && param?.sortBy) {
      switch (param.sortAs) {
        case 'text':
          sortedData.sort((a, b) => param.sortBy === 'asc' ? a[param.columnName].localeCompare(b[param.columnName]) : b[param.columnName].localeCompare(a[param.columnName])); // text sort
          break;
        case 'number':
          sortedData.sort((a, b) => param.sortBy === 'asc' ? Number(a[param.columnName]) - Number(b[param.columnName]) : Number(b[param.columnName]) - Number(a[param.columnName]));
          break;
        case 'date':
          sortedData.sort((a, b) => param.sortBy === 'asc' ? +new Date(a[param.columnName]) - +new Date(b[param.columnName]) : +new Date(b[param.columnName]) - +new Date(a[param.columnName]));
          break;
        default:
          break;
      }
    }

    return sortedData;
  }

}
