import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchByText'
})
export class SearchByKeyPipe implements PipeTransform {

  transform(results: Array<any>, searchText: string): Array<any> {
    if (!searchText) {
      return results;
    }

    results = results.filter(row => Object.keys(row)
      .some(key => row[key].toString().toLowerCase().includes(searchText.toLowerCase()))
    );

    return results;
  }

}
