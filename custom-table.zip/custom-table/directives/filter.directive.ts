import { Directive, ElementRef, ViewContainerRef, ComponentFactoryResolver, ComponentRef, Input, Renderer2 } from '@angular/core';
import { TableComponent } from '../table/table.component';
import { FilterColumnComponent } from '../table/filter-column/filter-column.component';

@Directive({
  selector: '[filter]'
})
export class FilterDirective {
  @Input() filter: TableComponent;
  @Input() id: string;
  
  constructor(
    private element: ElementRef,
    private viewContainerRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver,
    private renderer: Renderer2
  ) { }

  ngOnInit() {   
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(FilterColumnComponent);
    const componentRef = this.viewContainerRef.createComponent(componentFactory);
    //componentRef.instance.dataSource = this.filter.dataSource;
    componentRef.instance.columnName = this.id;
    this.renderer.appendChild(this.element.nativeElement, componentRef.location.nativeElement);
  }
}